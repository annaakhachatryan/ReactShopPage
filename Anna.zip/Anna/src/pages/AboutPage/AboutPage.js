import React from 'react'

export const AboutPage = () => {
    return (
        <div>AboutPage</div>
    )
}
