import React, { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import {
    decrementQuantity,
    incrementQuantity,
    removeCartItem,
    selectWishCard,
    setWishCard,
} from '../../store/slices/wishCartSlice/wishCardSlice';

export const WishCard = () => {
    const { addToWishCard } = useSelector(selectWishCard);
    const dispatch = useDispatch();

    useEffect(() => {
        const wishCard = localStorage.getItem('wishCard');
        if (wishCard) {
            dispatch(setWishCard(JSON.parse(wishCard)));
        }
    }, []);

    useEffect(() => {
        localStorage.setItem('wishCard', JSON.stringify(addToWishCard));
    }, [addToWishCard]);

    const handleRemoveItem = (itemId) => {
        dispatch(removeCartItem(itemId))
    };

    const handleIncrementQuantity = (itemId) => {
        dispatch(incrementQuantity(itemId));
    };

    const handleDecrementQuantity = (itemId) => {
        dispatch(decrementQuantity(itemId));
    };

    const calculateTotalPrice = () => {
        let countPrice = 0;
        addToWishCard.map((product) => {
            const price = product.price * product.quantity;
            countPrice += price;
            return countPrice;
        });
        return countPrice;
    };

    return (
        <div>
            <h3 style={{ textAlign: 'center' }}>Total Price: $ {Math.round(calculateTotalPrice())}</h3>
            <div className='HomePage' style={{ display: 'flex' }}>
                {addToWishCard?.map((product) => (
                    <div key={product?.id} className='prDiv'>
                        <div className='eachProductHome'>
                            <p>{product?.title}</p>
                            <p>{product?.description}</p>
                            <p>{product?.category}</p>
                            <img style={{ width: '50px', height: '50px' }} src={product.image} alt='' />
                            <div className='btnIconWish'>
                                <p>$ {Math.round(product?.price)}</p>
                                <h3>{product?.price && <p>All amount : $ {product?.price * product?.quantity}</p>}</h3>
                            </div>
                            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                                <button className='edit' onClick={() => handleDecrementQuantity(product.id)}>
                                    -
                                </button>
                                <p style={{ fontSize: '18px' }}> {product.quantity}</p>
                                <button className='edit' onClick={() => handleIncrementQuantity(product.id)}>
                                    +
                                </button>
                            </div>
                            <button className='edit' onClick={() => handleRemoveItem(product.id)}>
                                Remove Card
                            </button>
                        </div>
                    </div>
                ))}
            </div>
        </div>
    );
};
