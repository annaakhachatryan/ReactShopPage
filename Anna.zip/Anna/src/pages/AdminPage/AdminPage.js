import React, { useRef, useState, useEffect } from 'react';
import { Navbar } from '../../components/Navbar/Navbar';
import { useDispatch, useSelector } from 'react-redux';
import { selectRegisterPasswordData, togglePasswordVisibility } from '../../store/slices/passwordSlice/passwordSlice';
import { RiEyeCloseFill, RiEyeFill } from 'react-icons/ri';
import { FaUser, FaPhone, FaUpload } from 'react-icons/fa';
import './AdminPage.css';
import { getEditUser, selectRegisterData } from '../../store/slices/registrationData/registrationSlice';
import { editUserFetch, fetchDeleteUser, getFetchUsers, postBlockedFetchUser, unBlockFetchUser } from '../../store/slices/registrationData/registrationDataAPI';

export const AdminPage = () => {
    const dispatch = useDispatch();
    const { usersData, editUser, blockedUsers } = useSelector(selectRegisterData);
    const { passwordVisible } = useSelector(selectRegisterPasswordData);
    const [search, setSearch] = useState([]);
    const [isFormVisible, setFormVisible] = useState(false);
    const [newImg, setNewImg] = useState('');
    const filterData = search.length ? search : usersData;
    const [editItemValue, setEditItemValue] = useState({
        id: '',
        name: '',
        lastName: '',
        login: '',
        password: '',
        confirmPassword: '',
        email: '',
        phoneNumber: '',
        avatar: '',
    });
    const editFormRef = useRef(null);

    useEffect(() => {
        dispatch(getFetchUsers());
    }, [dispatch]);

    const onChangeImage = (e) => {
        let reader = new FileReader();
        reader.onload = () => {
            setNewImg(reader.result);
        };
        reader.readAsDataURL(e.target.files[0]);
    };

    const changeInputsValues = (e) => {
        const { name, value } = e.target;
        setEditItemValue({ ...editItemValue, [name]: value });
    };

    const handlerSubmit = (e) => {
        e.preventDefault();
        const [{ value: name }, { value: lastName }, { value: login }, { value: password }, { value: phoneNumber }, { value: confirmPassword }, { value: email }] = editFormRef.current;

        // if (password !== confirmPassword) {
        //     alert("no")
        //     return
        // } 

        dispatch(editUserFetch({
            id: editItemValue.id,
            name,
            lastName,
            login,
            password,
            confirmPassword,
            email,
            phoneNumber,
            avatar: newImg ? newImg : editItemValue.avatar
        }))
        setEditItemValue({
            id: '',
            name: '',
            lastName: '',
            login: '',
            password: '',
            confirmPassword: '',
            email: '',
            phoneNumber: '',
            avatar: ''
        })
        alert('You have already edited the user!')
    };

    const handleEdit = (editData) => {
        setEditItemValue({
            id: editData.id,
            name: editData.name,
            lastName: editData.lastName,
            login: editData.login,
            password: editData.password,
            confirmPassword: editData.confirmPassword,
            email: editData.email,
            phoneNumber: editData.phoneNumber,
            avatar: editData.avatar
        })
        dispatch(getEditUser(editUser));
    };

    const handlerBlockUser = (user) => {
        if (blockedUsers.length > 0) {
            const blocked = blockedUsers.find(item => item.id === user.id)
            blocked ? dispatch(unBlockFetchUser(user.id))
                : dispatch(postBlockedFetchUser(user))
        } else {
            dispatch(postBlockedFetchUser(user))
        }
    }

    const filterUser = (e) => {
        setSearch(usersData.filter((item) => item.name.toLowerCase().includes(e.target.value) || item.name.toUpperCase().includes(e.target.value)));
    };

    const handlerDelete = (id) => {
        dispatch(fetchDeleteUser(id));
    };

    const handleTogglePasswordVisibility = () => {
        dispatch(togglePasswordVisibility());
    };

    const openForm = () => {
        setFormVisible(true);
    };
    const closeForm = () => {
        setFormVisible(false);
    };

    return (
        <div className='adminPage'>
            <div className='adminContainer'>
                <Navbar />
            </div>
            <div>
                <input className='inp' type='text' placeholder='Search ...' onChange={filterUser} />
            </div>
            <h2 style={{ padding: '0 10px', color: 'purple' }}>Users</h2>
            <div className='bigDiv'>
                <div className='eachUser'>
                    <table>
                        <tr>
                            <th>ID</th>
                            <th>Name</th>
                            <th>LastName</th>
                            <th>Login</th>
                            <th>Password</th>
                            <th>Confirm Password</th>
                            <th>Email</th>
                            <th>Phone Number</th>
                            <th>Avatar</th>
                            <th>Delete</th>
                            <th>Edit</th>
                            <th>Block User</th>
                        </tr>
                        {filterData.map((user) => (
                            <tr key={user?.id}>
                                <td>{user?.id}</td>
                                <td>{user?.name}</td>
                                <td>{user?.lastName}</td>
                                <td>{user?.login}</td>
                                <td>{user?.password.slice(0, 3).replace(/./g, '*') + user.password.slice(3, 5) + user.password.slice(5, 10).replace(/./g, '*')}</td>
                                <td>{user?.confirmPassword.slice(0, 3).replace(/./g, '*') + user.confirmPassword.slice(3, 5) + user.confirmPassword.slice(5, 10).replace(/./g, '*')}</td>
                                <td>{user?.email}</td>
                                <td>{user?.phoneNumber}</td>
                                <td>
                                    <img style={{ width: '30px', height: '30px', borderRadius: '50%' }} src={user?.avatar} alt='not' />
                                </td>
                                <td>
                                    <button className='delete' onClick={() => handlerDelete(user.id)}> Delete</button>
                                </td>
                                <td>
                                    <button className='edit' onClick={() => handleEdit(user)}> {!isFormVisible && <span onClick={openForm}>Edit</span>} </button>
                                </td>
                                <td>
                                    <button className='edit' onClick={() => handlerBlockUser(user)}
                                        style={blockedUsers.find(item => item.id === user.id) && { color: 'red' }}>
                                        Block
                                    </button>
                                </td>
                            </tr>
                        ))}
                    </table>
                </div>
            </div>
            <div className='editUserItem'>
                <div className='bigDiv'>
                    {isFormVisible && (
                        <form ref={editFormRef} onSubmit={handlerSubmit} className='eachItem'>
                            <div className='eachDiv'>
                                <label>Name</label>
                                <FaUser className='icon' />
                                <input onChange={changeInputsValues} name='name'
                                    value={editItemValue?.name ? editItemValue.name : ''} placeholder='Name' type='text' />
                            </div>
                            <div className='eachDiv'>
                                <label>Last name</label>
                                <FaUser className='icon' />
                                <input onChange={changeInputsValues} name='lastName'
                                    value={editItemValue?.lastName ? editItemValue.lastName : ''} placeholder='Last Name' type='text' />
                            </div>
                            <div className='eachDiv'>
                                <label>Login</label>
                                <FaUser className='icon' />
                                <input onChange={changeInputsValues} name='login'
                                    value={editItemValue?.login ? editItemValue.login : ''} placeholder='Login' type='text' />
                            </div>
                            <div className='eachDiv'>
                                <label>Password</label>
                                <FaUser className='icon' />
                                <input
                                    onChange={changeInputsValues}
                                    name='password' value={editItemValue?.password ? editItemValue.password : ''} placeholder='Password'
                                    type={passwordVisible ? 'text' : 'password'}
                                />
                                <span className='eye' onClick={handleTogglePasswordVisibility}>
                                    {passwordVisible ? <RiEyeFill /> : <RiEyeCloseFill />}
                                </span>
                            </div>
                            <div className='eachDiv'>
                                <label>Confirm password</label>
                                <FaUser className='icon' />
                                <input placeholder='Confirm Password' name='confirmPassword'
                                    onChange={changeInputsValues} value={editItemValue?.confirmPassword ? editItemValue.confirmPassword : ''}
                                    type={passwordVisible ? 'text' : 'password'} />
                                <span className='eye' onClick={handleTogglePasswordVisibility}>{passwordVisible ? <RiEyeFill /> : <RiEyeCloseFill />}</span>
                            </div>
                            <div className='eachDiv'>
                                <label>Email</label>
                                <FaUser className='icon' />
                                <input onChange={changeInputsValues} name='email' value={editItemValue?.email ? editItemValue.email : ''} placeholder='Email' type='text' />
                            </div>
                            <div className='eachDiv'>
                                <label>Phone number</label>
                                <FaPhone className='icon' />
                                <input name='phoneNumber' onChange={changeInputsValues} value={editItemValue?.phoneNumber ? editItemValue.phoneNumber : ''} placeholder='Phone Number' type='text' />
                            </div>
                            <div className='eachDiv upload'>
                                <label>Choose file</label>
                                <div className='choose'>
                                    <FaUpload className='iconFile' /> Upload a file
                                    <input type='file' onChange={(e) => onChangeImage(e)} />
                                </div>
                            </div>
                            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                                <button className='edit'>
                                    Edit
                                </button>
                                <button className='edit' onClick={closeForm}>Close</button>
                            </div>
                        </form>
                    )}
                </div>
            </div>
        </div>
    );
};