import React from 'react'

export const NotFound = () => {
    return (
        <div>You can not enter your page. Your page is blocked</div>
    )
}
