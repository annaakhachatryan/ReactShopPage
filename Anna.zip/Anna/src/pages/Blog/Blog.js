import React from 'react'

export const Blog = () => {
    return (
        <div>Blog</div>
    )
}
