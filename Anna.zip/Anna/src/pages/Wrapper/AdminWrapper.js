import React from 'react'
import DashboardIcon from '@mui/icons-material/Dashboard';
import ProductionQuantityLimitsIcon from '@mui/icons-material/ProductionQuantityLimits';
import ListAltRoundedIcon from '@mui/icons-material/ListAltRounded';
import LocalShippingRoundedIcon from '@mui/icons-material/LocalShippingRounded';
import NotificationsNoneRoundedIcon from '@mui/icons-material/NotificationsNoneRounded';
import PsychologyOutlinedIcon from '@mui/icons-material/PsychologyOutlined';
import SettingsIcon from '@mui/icons-material/Settings';
import AccountCircleOutlinedIcon from '@mui/icons-material/AccountCircleOutlined';
import ExitToAppIcon from '@mui/icons-material/ExitToApp';

import { Link, Outlet } from 'react-router-dom';
import { LogOut } from '../../components/LogOut/LogOut';

import './AdminWrapper.css'

export const AdminWrapper = () => {
    return (
        <div className='Sidebar'>
            <div className='border'>
                <div className='top'>
                    <span className='logo'>Shop Name</span>
                </div>
                <hr />
                <header className='center'>
                    <ul>
                        <p className='title'>MAIN</p>
                        <li>
                            <DashboardIcon className='icon ' />
                            <Link to=''>Dashboard</Link>
                        </li>
                        <p className='title'>LISTS</p>
                        <li>
                            <ProductionQuantityLimitsIcon className='icon ' />
                            <Link to='products'>Products</Link>
                        </li>
                        <li>
                            <ListAltRoundedIcon className='icon ' />
                            <Link to='orders'>Orders</Link>
                        </li>
                        <li>
                            <LocalShippingRoundedIcon className='icon ' />
                            <Link to='delivery'>Delivery</Link>
                        </li>
                        <p className='title'>USEFUL</p>
                        <li>
                            <NotificationsNoneRoundedIcon className='icon ' />
                            <Link to='notifications'>Notifications</Link>
                        </li>
                        <p className='title'>SERVICE</p>
                        <li>
                            <PsychologyOutlinedIcon className='icon ' />
                            <Link to='logs'>Logs</Link>
                        </li>
                        <li>
                            <SettingsIcon className='icon ' />
                            <Link to='settings'>Settings</Link>
                        </li>
                        <p className='title'>USER</p>
                        <li>
                            <AccountCircleOutlinedIcon className='icon ' />
                            <Link to='profile'>Profile</Link>
                        </li>
                        <li>
                            <ExitToAppIcon className='icon ' />
                            <LogOut/>
                        </li>
                    </ul>
                </header>
                <div className='bottom'>
                    <div className='colorOption'></div>
                    <div className='colorOption'></div>
                </div>
            </div>
            <Outlet />
        </div>
    )
}
