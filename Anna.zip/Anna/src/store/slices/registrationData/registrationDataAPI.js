import { createAsyncThunk } from "@reduxjs/toolkit";

export const getFetchUsers = createAsyncThunk(
    'registrationData/getFetchUsers',
    async ()=> {
        const result = await fetch('http://localhost:3001/users')
        const userData = await result.json()
        return userData
    }
)

export const postFetchUser = createAsyncThunk(
    'registrationData/postFetchUser',
    async (data) =>{
        const result = await fetch('http://localhost:3001/users',{
            method:"POST",
            headers:{
                "Content-Type":"application/json"
            },
            body:JSON.stringify(data)
        })
        return result.json()
    }
)

export const fetchDeleteUser = createAsyncThunk(
    'registrationData/fetchDeleteUser',
    async (id)=>{
        await fetch(`http://localhost:3001/users/${id}`,{
            method:'DELETE',
            headers:{
                "Content-Type":"application/json"
            }
        })
        return id
    }
)

export const editUserFetch = createAsyncThunk(
    'registrationData/editUserFetch',
    async (editData) => {
        const result = await fetch(`http://localhost:3001/users/${editData.id}`, {
            method: 'PUT',
            headers: {
                "Content-type": "application/json"
            },
            body:JSON.stringify(editData)
        })
        return result.json()
    }
)

export const getBlockedFetchUser = createAsyncThunk(
    'registrationData/getBlockedFetchUser',
    async () => {
        const result = await fetch('http://localhost:3001/blockedUsers')
        const blockedUsers = await result.json()
        return blockedUsers;
    }
)

export const postBlockedFetchUser = createAsyncThunk(
    'registrationData/postBlockedFetchUser',
    async (data) => {
        const result = await fetch('http://localhost:3001/blockedUsers', {
            method: 'POST',
            headers: {
                "Content-type": "application/json",
            },
            body:JSON.stringify(data)
        })
        return data
    }
)

export const unBlockFetchUser = createAsyncThunk(
    'registrationData/unblockFetchUser',
    async (id) => {
        const result = await fetch(`http://localhost:3001/blockedUsers/${id}`, {
            method: 'DELETE',
            headers: {
                "Content-type": "application/json",
            },  
        })
        return id
    }
)
