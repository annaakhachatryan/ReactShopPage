import { createSlice } from "@reduxjs/toolkit";
import { addProduct, deleteProduct, editProduct, fetchProducts, postFetchProduct } from "./ProductAPI";

const productsDataSlice = createSlice({
    name: 'productsData',
    initialState: {
        items: [],
        editProduct: null,
    },
    reducers: {
        getEditProducts(state, { payload }) {
            state.editProduct = payload
        }
    },
    extraReducers: {
        [fetchProducts.fulfilled]: (state, action) => {
            state.items = action.payload;
        },
        [addProduct.fulfilled]: (state, action) => {
            state.items.push(action.payload);
        },
        [deleteProduct.fulfilled]: (state, action) => {
            state.items = state.items.filter(product => product.id !== action.payload);
        },
        [editProduct.fulfilled]: (state, { payload }) => {
            state.items = [...state.items.map(product => product.id === payload.id ? payload : product)]
            state.editProduct = null
        },
        [postFetchProduct.fulfilled]: (state, { payload }) => {
            state.items = [
                ...state.items,
                {
                    id: payload.id,
                    title: payload.title,
                    price: payload.price,
                    description: payload.description,
                    category: payload.category,
                    image: payload.image
                }
            ]
            state.editProduct = null
        },
    },
})

export const selectProductsDataSlice = state => state.productsData

export const { clearError } = productsDataSlice.actions
export const ProductsDataReducer = productsDataSlice.reducer