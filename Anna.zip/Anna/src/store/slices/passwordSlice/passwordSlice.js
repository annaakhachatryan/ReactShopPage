import { createSlice } from '@reduxjs/toolkit';

const passwordSlice = createSlice({
    name: 'password',
    initialState:{
        passwordVisible: false,
        password: '',
    },
    reducers: {
        togglePasswordVisibility: (state) => {
            state.passwordVisible = !state.passwordVisible;
        },
    },
});

export const selectRegisterPasswordData = state => state.password

export const { togglePasswordVisibility, setPassword } = passwordSlice.actions;
export const registrationPasswordReducer = passwordSlice.reducer

