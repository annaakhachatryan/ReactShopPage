import { createSlice } from "@reduxjs/toolkit";

const wishCardSlice = createSlice({
    name:'wishCard',
    initialState:{
        addToWishCard:[],
        quantity:0
    },
    reducers:{
        addWishCard:(state, {payload})=>{
            const findWish = state.addToWishCard.findIndex(item => item.id === payload.id)
            if(findWish >= 0){
                state.addToWishCard[findWish].quantity += 1
            }else{
                const wish = {...payload, quantity: 1}
                state.addToWishCard.push(wish)
            }
        },
        removeCartItem(state, action) {
            state.addToWishCard = state.addToWishCard.filter(product => product.id !== action.payload);
        },
        incrementQuantity : (state, {payload}) => {
            const increment = state.addToWishCard.find(item => item.id === payload);
            if (increment) {
                increment.quantity++;
            }
        },
        decrementQuantity: (state, {payload}) => {
            const decrement = state.addToWishCard.find(item => item.id === payload);
            if (decrement && decrement.quantity > 0) {
                decrement.quantity--;
            }
        },
    },
    extraReducers:{}
})

export const selectWishCard = state => state.wishCard

export const { addWishCard, removeCartItem, incrementQuantity, decrementQuantity } = wishCardSlice.actions
export const wishCardReducer = wishCardSlice.reducer