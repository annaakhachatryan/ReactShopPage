import { createSlice } from "@reduxjs/toolkit";
import {  editUserFetch, fetchDeleteUser, getBlockedFetchUser, getFetchUsers, postBlockedFetchUser, postFetchUser, unBlockFetchUser } from "./registrationDataAPI";

const registrationSlice = createSlice({
    name:'registrationData',
    initialState:{
        usersData:[],
        currentUser:null,
        isAdminAuth: false,
        isUserAuth: false,
        editUser: null,
        blockedUsers: [],
    },
    reducers:{
        isAuthAdmin(state, {payload}) {
            state.isAdminAuth = payload
        },
        isAuthUser(state, {payload}) {
            state.isUserAuth = payload
        },
        getCurrentUser(state, {payload}) {
            state.currentUser = payload
        },
        getEditUser(state,{payload}){
            state.editUser = payload
        }
    },
    extraReducers:{
        [getFetchUsers.fulfilled] : (state, {payload}) => {
            state.usersData = payload
        },
        [fetchDeleteUser.fulfilled] : (state, {payload}) => {
            state.usersData = state.usersData.filter(user => user.id !== payload)
        },
        [postFetchUser.fulfilled] : (state, {payload}) => {
            state.usersData =  [
                ...state.usersData,
                {
                    id: payload.id,
                    name: payload.name,
                    lastName: payload.lastName,
                    login: payload.login,
                    password: payload.password,
                    email:payload.email,
                    phoneNumber:payload.phoneNumber,
                    avatar: payload.avatar,
                }
            ]
            state.editUser = null
        },
        [editUserFetch.fulfilled] : (state, {payload}) => {
            state.usersData =  [...state.usersData.map(user => user.id === payload.id ? payload : user)]
            state.editUser = null
        },
        [getBlockedFetchUser.fulfilled] : (state,{payload}) => {
            state.blockedUsers = payload
        },
        [postBlockedFetchUser.fulfilled] : (state,{payload}) => {
            state.blockedUsers = [
                ...state.blockedUsers,
                { 
                    id: payload.id,
                    name: payload.name,
                    lastName: payload.lastName,
                    login: payload.login,
                    password: payload.password,
                    confirmPassword: payload.confirmPassword,
                    email:payload.email,
                    phoneNumber:payload.phoneNumber,
                    avatar: payload.avatar,
                    user:false
                }
            ]
        },
        [unBlockFetchUser.fulfilled]: (state,{payload}) => {
            state.blockedUsers = [...state.blockedUsers.filter(user => user.id !== payload)]
        }
    }
})

export const selectRegisterData = state => state.registrationData

export const { isAuthAdmin, getCurrentUser, userDelete, editUserData, getEditUser, isAuthUser } = registrationSlice.actions
export const registrationReducer = registrationSlice.reducer