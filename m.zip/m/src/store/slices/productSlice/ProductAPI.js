import { createAsyncThunk } from "@reduxjs/toolkit"

export const fetchProducts = createAsyncThunk(
    'productsData/fetchProducts',
    async () => {
        const response = await fetch('http://localhost:3001/products');
        const data = await response.json();
        return data;
    });

export const postFetchProduct = createAsyncThunk(
    'productsData/postFetchProduct',
    async (data) => {
        const result = await fetch('http://localhost:3001/products', {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify(data)
        })
        return result.json()
    }
)

export const addProduct = createAsyncThunk(
    'productsData/addProduct',
    async (product) => {
        const result = await fetch('http://localhost:3001/products', {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify(product)
        })
        const data = await result.json();
        return data;
    }
)


export const deleteProduct = createAsyncThunk(
    'productsData/deleteProduct',
    async (productId) => {
        await fetch(`http://localhost:3001/products/${productId}`, {
            method: 'DELETE',
        });
        return productId;
    });

export const editProduct = createAsyncThunk(
    'productsData/editProduct',
    async (product) => {
        const response = await fetch(`http://localhost:3001/products/${product.id}`, {
            method: 'PUT',
            headers: {
                "Content-type": "application/json"
            },
            body: JSON.stringify(product)
        })
        return response.json()
    }
);