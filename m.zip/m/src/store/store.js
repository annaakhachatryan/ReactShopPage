import { configureStore } from "@reduxjs/toolkit";
import { registrationReducer } from "./slices/registrationData/registrationSlice";
import { registrationPasswordReducer } from "./slices/passwordSlice/passwordSlice";
import { ProductsDataReducer } from "./slices/productSlice/productSlice";
import { wishCardReducer } from "./slices/wishCartSlice/wishCardSlice";

const store = configureStore({
    reducer:{
        registrationData:registrationReducer,
        productsData: ProductsDataReducer,
        password: registrationPasswordReducer,
        wishCard: wishCardReducer,
    },
    middleware:(getDefaultMiddleware) => [...getDefaultMiddleware()]
})

export default store