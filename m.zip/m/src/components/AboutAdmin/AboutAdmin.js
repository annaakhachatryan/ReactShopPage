import React, { useState } from 'react'
import { useSelector } from 'react-redux'
import { selectRegisterData } from '../../store/slices/registrationData/registrationSlice';

import './AboutAdmin.css'

export const AboutAdmin = () => {
    const { currentUser } = useSelector(selectRegisterData)
    const [hideInfo, setHideInfo] = useState(true);

    const hideAdminInfo = () => {
        setHideInfo(!hideInfo);
    };

    return (
        <div className='aboutAdmin'>
            {
                hideInfo && (
                    <div className='eachAdmin'>
                        <span onClick={hideAdminInfo} className='deleteInfo'>X</span>
                        <p><span>ID : </span>{currentUser.id}</p>
                        <p><span>Name : </span>{currentUser.name}</p>
                        <p><span>LastName : </span>{currentUser.lastName}</p>
                        <p><span>Login : </span>{currentUser.login}</p>
                        <p><span>Password : </span>{currentUser.password}</p>
                        <p><span>Confirm Password : </span>{currentUser.confirmPassword}</p>
                        <p><span>Email : </span>{currentUser.email}</p>
                        <p><span>Phone Number : </span>{currentUser.phoneNumber}</p>
                    </div>
                )
            }
        </div>
    )
}
