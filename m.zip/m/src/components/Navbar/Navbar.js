import React, { useState } from 'react'

import DarkModeOutlinedIcon from '@mui/icons-material/DarkModeOutlined';
import NotificationsOutlinedIcon from '@mui/icons-material/NotificationsOutlined';
import ChatBubbleOutlineOutlinedIcon from '@mui/icons-material/ChatBubbleOutlineOutlined';
import ListIcon from '@mui/icons-material/List';
import { useSelector } from 'react-redux';
import { selectRegisterData } from '../../store/slices/registrationData/registrationSlice';
import './Navbar.css'
import { Link } from 'react-router-dom';
import LightModeOutlinedIcon from '@mui/icons-material/LightModeOutlined';
import { AboutAdmin } from '../AboutAdmin/AboutAdmin';
import { isVisible } from '@testing-library/user-event/dist/utils';

export const Navbar = () => {
    const {currentUser} = useSelector(selectRegisterData)
    const [isDarkMode, setIsDarkMode] = useState(false);
    const [isInfoVisible, setInfoVisible] = useState(false);


    const toggleDarkMode = () => {
        setIsDarkMode(!isDarkMode);
    };
    const toggleInfo = () => {
        setInfoVisible(!isInfoVisible);
    };

    if (isDarkMode) {
        document.body.style.backgroundColor = '#222';
        document.body.style.color = '#fff';
    } else {
        document.body.style.backgroundColor = '#fff';
        document.body.style.color = '#222';
    }

    return (
        <div className='Navbar'>
            <div className='wrapper'>
                <div className='search'>
                    <Link className='home' to='/homePage'>Home</Link>
                </div>
                <div className='items'>
                    <div className='item'>
                        <div onClick={toggleDarkMode}>
                            {isDarkMode ? (
                                <DarkModeOutlinedIcon />
                            ) : (
                                <LightModeOutlinedIcon/>
                            )}
                        </div>
                    </div>
                    <div className='item'>
                        <NotificationsOutlinedIcon className='icons'additive />
                    </div>
                    <div className='item'>
                        <ChatBubbleOutlineOutlinedIcon className='icons'/>
                    </div>
                    <div className='item'>
                        <ListIcon
                        className='icons'/>
                    </div>
                    <div className='item'>
                        <img onClick={toggleInfo} src={currentUser.avatar} alt=""/>
                        {
                            isInfoVisible && (
                                <div>
                                    <AboutAdmin/>
                                </div>
                            )
                        }
                    </div>
                </div>
            </div>
        </div>
    )
}
