import React from 'react'
import { Route, Routes } from 'react-router'
import { Wrapper } from '../../pages/Wrapper/Wrapper'
import { RegisterPage } from '../../pages/RegisterPage/RegisterPage'
import { LoginPage } from '../../pages/LoginPage/LoginPage'
import { useSelector } from 'react-redux'
import { selectRegisterData } from '../../store/slices/registrationData/registrationSlice'
import { AdminPage } from '../../pages/AdminPage/AdminPage'
import { AdminWrapper } from '../../pages/Wrapper/AdminWrapper'
import { Users } from '../../pages/Users/Users'
import { Products } from '../../pages/Products/Products'
import { Orders } from '../../pages/Orders/Orders'
import { Delivery } from '../../pages/Delivery/Delivery'
import { Notifications } from '../../pages/Notifications/Notifications'
import { Logs } from '../../pages/Logs/Logs'
import { Settings } from '../../pages/Settings/Settings'
import { Profile } from '../../pages/Profile/Profile'
import { HomePage } from '../../pages/HomePage/HomePage'
import { Blog } from '../../pages/Blog/Blog'
import { AboutPage } from '../../pages/AboutPage/AboutPage'
import { Service } from '../../pages/Service/Service'
import { Contact } from '../../pages/Contact/Contact'
import { WishCard } from '../../pages/WishCard/WishCard'
import { NotFound } from '../../pages/NotFound/NotFound'

export const AppRouter = () => {
    const {isAdminAuth} = useSelector(selectRegisterData)
    return (
        <div>
            <Routes>
                <Route path="homePage/" element={<Wrapper/>}>
                    <Route index element={<HomePage/>}/>
                    <Route path='aboutPage' element={<AboutPage/>}/>
                    <Route path='blog' element={<Blog/>}/>
                    <Route path='service' element={<Service/>}/>
                    <Route path='contact' element={<Contact/>}/>
                    <Route path='wishCard' element={<WishCard/>}/>
                </Route>
                <Route path='/' element={<LoginPage/>}/>
                <Route path='/registration' element={<RegisterPage/>}/>
                <Route path='/notFound' element={<NotFound/>}/>
                {
                isAdminAuth && 
                    <Route path='adminPage/' element={<AdminWrapper/>}>
                        <Route index element={<AdminPage/>}/>
                        <Route path='users' element={<Users/>}/>
                        <Route path='products' element={<Products/>}/>
                        <Route path='orders' element={<Orders/>}/>
                        <Route path='delivery' element={<Delivery/>}/>
                        <Route path='notifications' element={<Notifications/>}/>
                        <Route path='logs' element={<Logs/>}/>
                        <Route path='settings' element={<Settings/>}/>
                        <Route path='profile' element={<Profile/>}/>
                    </Route>
                }
            </Routes>
        </div>
    )
}
