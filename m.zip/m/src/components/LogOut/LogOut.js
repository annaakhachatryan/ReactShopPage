import React from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { useNavigate } from 'react-router'
import { getCurrentUser, selectRegisterData } from '../../store/slices/registrationData/registrationSlice'

export const LogOut = () => {
    const dispatch = useDispatch()
    const navigate = useNavigate()
    const {currentUser} =useSelector(selectRegisterData)

    const logOut = () => {
        if(currentUser){
            dispatch(getCurrentUser(null))
            navigate('/')
        }
    }
    return (
        <div>
            <span onClick={logOut}>LogOut</span>
        </div>
    )
}
