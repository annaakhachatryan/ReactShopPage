import React, { useEffect, useRef } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { selectRegisterPasswordData, togglePasswordVisibility } from '../../store/slices/passwordSlice/passwordSlice'
import { useDispatch } from 'react-redux'
import { useSelector } from 'react-redux'
import { getCurrentUser, isAuthAdmin, isAuthUser, selectRegisterData } from '../../store/slices/registrationData/registrationSlice'
import { getFetchUsers } from '../../store/slices/registrationData/registrationDataAPI'
import { FaUser } from 'react-icons/fa';
import { RiEyeCloseFill, RiEyeFill } from 'react-icons/ri';
import './LoginPage.css'
import { getBlockedFetchUser } from '../../store/slices/registrationData/registrationDataAPI'

export const LoginPage = () => {
    const dispatch = useDispatch()
    const navigate = useNavigate()
    const { usersData, blockedUsers } = useSelector(selectRegisterData)
    const { passwordVisible } = useSelector(selectRegisterPasswordData);

    useEffect(() => { dispatch(getFetchUsers()) }, [])
    useEffect(() => { dispatch(getBlockedFetchUser()) }, [])
     
    const loginRef = useRef(null)
    
    const handleSubmit = (e) => {
        e.preventDefault();
        const [{ value: emailOrLogin }, { value: password }] = loginRef.current;

        const user = usersData.find((user) =>(user.email === emailOrLogin || user.login === emailOrLogin) && user.password === password);

        const blockedUser = blockedUsers.find((user) => (user.email === emailOrLogin || user.login === emailOrLogin) && user.password === password)
        console.log(usersData);
        console.log(blockedUsers);

        if (user?.admin) {
            dispatch(isAuthAdmin(true));
            dispatch(getCurrentUser(user));
            navigate('/adminPage');
        } else if (user) {
            dispatch(getCurrentUser(user));
            if (blockedUser) {
                 alert('User is blocked. Please contact support.') 
                navigate('/notFound')
                return
            }
           navigate('/homePage')
        }
    };


    const handleTogglePasswordVisibility = () => {
        dispatch(togglePasswordVisibility());
    };
    return (
        <div className='loginPage'>
            <div className='bigDiv'>
                <form ref={loginRef} onSubmit={handleSubmit}>
                <div className='eachDiv'>
                        <label>Email</label>
                        <FaUser className='icon' />
                        <input placeholder='Email' type='text' />
                    </div>
                    <div className='eachDiv'>
                        <label>Password</label>
                        <FaUser className='icon' />
                        <input placeholder='Password' type={passwordVisible ? 'text' : 'password'} />
                        <span className='eye' onClick={handleTogglePasswordVisibility}>{passwordVisible ? <RiEyeFill /> : <RiEyeCloseFill />}</span>
                    </div>
                    <div className='btn'>
                        <button className='registerBtn'>Login</button>
                        <span>Don't you have an account? <Link to="/registration">Register</Link></span>
                    </div>
                </form>
            </div>
        </div>
    )
}
