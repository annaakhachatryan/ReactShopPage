import React from 'react'

export const Notifications = () => {
    return (
        <div>Notifications</div>
    )
}
