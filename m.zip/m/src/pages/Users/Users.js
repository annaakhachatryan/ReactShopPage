import React from 'react'

export const Users = () => {
    return (
        <div>Users</div>
    )
}
