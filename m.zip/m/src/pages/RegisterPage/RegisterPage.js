import React, { useEffect, useRef, useState } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { getFetchUsers, postFetchUser } from '../../store/slices/registrationData/registrationDataAPI'
import { selectRegisterData } from '../../store/slices/registrationData/registrationSlice'
import { RiEyeCloseFill, RiEyeFill } from 'react-icons/ri';
import { FaUser, FaPhone, FaUpload } from 'react-icons/fa';
import { AiOutlineMenu } from 'react-icons/ai';
import { Link } from 'react-router-dom';
import { selectRegisterPasswordData, togglePasswordVisibility } from '../../store/slices/passwordSlice/passwordSlice';
import './Register.css'

export const RegisterPage = () => {
    const dispatch = useDispatch()
    const { usersData } = useSelector(selectRegisterData)
    const [newImg, setNewImg] = useState(null)
    const {passwordVisible} = useSelector(selectRegisterPasswordData);

    useEffect(() => { dispatch(getFetchUsers()) }, [])

    const registerRef = useRef(null)
    const handlerSubmit = (e) => {
        e.preventDefault()
        const [{ value: name }, { value: lastName }, { value: login }, { value: password },{ value: confirmPassword }, { value: email }, { value: phoneNumber }] = registerRef.current

        const uniqUser = usersData.find(user => user.login === login || user.email === email)
        if (uniqUser) {
            return
        }

        dispatch(postFetchUser({
            id: new Date().getTime().toString(),
            name, 
            lastName, 
            login, 
            password, 
            confirmPassword, 
            email, 
            phoneNumber,
            avatar: newImg,
        }))
    }

    const handleTogglePasswordVisibility = () => {
        dispatch(togglePasswordVisibility());
    };

    const changeFile = (e) => {
        let reader = new FileReader();
        reader.onload = () => {
            setNewImg(reader.result);
        }
        reader.readAsDataURL(e.target.files[0]);
    }

    return (
        <div className='RegisterPage'>
            <div className='bigDiv'>
                <form ref={registerRef} onSubmit={handlerSubmit}>
                    <div className='eachDiv'>
                        <label>Name</label>
                        <FaUser className='icon' />
                        <input placeholder='Name' type='text' />
                    </div>
                    <div className='eachDiv'>
                        <label>Last name</label>
                        <FaUser className='icon' />
                        <input placeholder='Last Name' type='text' />
                    </div>
                    <div className='eachDiv'>
                        <label>Login</label>
                        <FaUser className='icon' />
                        <input placeholder='Login' type='text' />
                    </div>
                    <div className='eachDiv'>
                        <label>Department / Office</label>
                        <AiOutlineMenu className='icon'/>
                        <select className='select'>
                            <option value="">Select your Department/Office</option>
                            <option>Department of Engineering</option>
                            <option>Department of Agriculture</option>
                            <option >Accounting Office</option>
                            <option >Mayor's Office</option>
                            <option >Tourism Office</option>
                        </select>
                    </div>
                    <div className='eachDiv'>
                        <label>Password</label>
                        <FaUser className='icon' />
                        <input placeholder='Password' type={passwordVisible ? 'text' : 'password'} />
                        <span className='eye' onClick={handleTogglePasswordVisibility}>{passwordVisible ? <RiEyeFill /> : <RiEyeCloseFill />}</span>
                    </div>
                    <div className='eachDiv'>
                        <label>Confirm password</label>
                        <FaUser className='icon' />
                        <input placeholder='Confirm Password' type={passwordVisible ? 'text' : 'password'} />
                        <span className='eye' onClick={handleTogglePasswordVisibility}>{passwordVisible ? <RiEyeFill /> : <RiEyeCloseFill />}</span>
                    </div>
                    <div className='eachDiv'>
                        <label>Email</label>
                        <FaUser className='icon' />
                        <input placeholder='Email' type='text' />
                    </div>
                    <div className='eachDiv'>
                        <label>Phone number</label>
                        <FaPhone className='icon' />
                        <input placeholder='Phone Number' type='text' />
                    </div>
                    <div className='eachDiv upload'>
                        <label>Choose file</label>
                        <div className='choose'>
                            <FaUpload className='iconFile' /> Upload a file
                            <input type='file' onChange={(e) => { changeFile(e) }} />
                        </div>
                    </div>
                    <div className='btn'>
                        <button className='registerBtn'>Register</button>
                        <span>Do you have an account? <Link to="/">Login</Link></span>
                    </div>
                </form>
            </div>
        </div>
    )
}
