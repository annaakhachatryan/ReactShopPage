import React  from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { decrementQuantity, incrementQuantity, removeCartItem, selectWishCard } from '../../store/slices/wishCartSlice/wishCardSlice'
import StarBorderIcon from '@mui/icons-material/StarBorder';

export const WishCard = () => {
    const { addToWishCard } = useSelector(selectWishCard)
    const dispatch = useDispatch()
    const handleRemoveItem = (itemId) => {
        dispatch(removeCartItem(itemId));
    };
    const handleIncrementQuantity = (itemId) => {
        dispatch(incrementQuantity(itemId));
    };
    const handleDecrementQuantity = (itemId) => {
        dispatch(decrementQuantity(itemId));
    };
        return (
        <div className='HomePage'>
            {
                addToWishCard?.map((product) => (
                    <div key={product?.id} className='prDiv'>
                        <div className='eachProductHome'>
                            <StarBorderIcon/><StarBorderIcon/><StarBorderIcon/><StarBorderIcon/><StarBorderIcon/>
                            <p>{product?.title}</p>
                            <p>{product?.description}</p>
                            <p>{product?.category}</p>
                            <img style={{ width: '50px', height: '50px' }} src={product.image} alt='' />
                            <div className='btnIconWish'>
                                <p>$ {product?.price}</p>
                            </div>
                            <div style={{display:'flex', alignItems:'center', justifyContent:'center'}}>
                                <button className='edit' onClick={() => handleDecrementQuantity(product.id)}>-</button>
                                <p style={{fontSize:'18px'}}> {product.quantity}</p>
                                <button className='edit' onClick={() => handleIncrementQuantity(product.id)}>+</button>
                            </div>
                            <button className='edit' onClick={() => handleRemoveItem(product.id)}>Remove Card</button>
                        </div>
                    </div>
                ))}
        </div>
    )
}
