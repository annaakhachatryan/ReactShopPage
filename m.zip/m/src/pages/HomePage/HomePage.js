import React, { useEffect } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { selectProductsDataSlice } from '../../store/slices/productSlice/productSlice'
import { fetchProducts } from '../../store/slices/productSlice/ProductAPI'
import ShoppingCartIcon from '@mui/icons-material/ShoppingCart';
import StarBorderIcon from '@mui/icons-material/StarBorder';
import './HomePage.css'
import { addWishCard } from '../../store/slices/wishCartSlice/wishCardSlice';

export const HomePage = () => {
    const dispatch = useDispatch()
    const {items} = useSelector(selectProductsDataSlice)
    useEffect(()=>{
        dispatch(fetchProducts())
    }, [dispatch])
    
    return (
        <div className='HomePage'>
            {items.map((product) => (
                <div  key={product?.id} className='prDiv'>
                    <div className='eachProductHome'>
                        <StarBorderIcon/><StarBorderIcon/><StarBorderIcon/><StarBorderIcon/><StarBorderIcon/>
                        <p>{product?.title}</p>
                        <p>{product?.description}</p>
                        <p>{product?.category}</p>
                        <img style={{ width: '50px', height: '50px' }} src={product.image} alt='' />
                        <div className='btnIconWish'>
                            <p>$ {product?.price}</p>
                            <button 
                                onClick={()=>dispatch(addWishCard(product))}>
                                    <ShoppingCartIcon/>
                            </button>
                        </div>
                    </div>
                </div>
            ))}
            
        </div>
    )
}
