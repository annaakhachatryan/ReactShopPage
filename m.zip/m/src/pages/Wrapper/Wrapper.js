import React, { useState } from 'react'
import {Link, Outlet} from 'react-router-dom'
import DarkModeOutlinedIcon from '@mui/icons-material/DarkModeOutlined';
import LightModeOutlinedIcon from '@mui/icons-material/LightModeOutlined';
import ShoppingCartIcon from '@mui/icons-material/ShoppingCart';
import { useSelector } from 'react-redux';
import { selectWishCard } from '../../store/slices/wishCartSlice/wishCardSlice';

export const Wrapper = () => {
    const {addToWishCard} = useSelector(selectWishCard)
    const [isDarkMode, setIsDarkMode] = useState(false);
    
    const toggleDarkMode = () => {
        setIsDarkMode(!isDarkMode);
    };

    if (isDarkMode) {
        document.body.style.backgroundColor = '#222';
        document.body.style.color = '#fff';
    } else {
        document.body.style.backgroundColor = '#fff';
        document.body.style.color = '#222';
    }
    return (
        <div className='Wrapper'>
            <div className='links'>
                <Link to=''>Home Page</Link>
                <Link to='aboutPage'>About Page</Link>
                <Link to='blog'>Blog</Link>
                <Link to='service'>Service</Link>
                <Link to='contact'>Contact</Link>
                <div className='wishCart'>
                    <div style={{margin:'5px'}} onClick={toggleDarkMode}>
                        {isDarkMode ? (
                            <DarkModeOutlinedIcon />
                        ) : (
                            <LightModeOutlinedIcon />
                        )}
                    </div>
                    <div style={{margin:'5px'}}>
                        <Link to='wishCard'> 
                            <div>
                                <div style={{display:'flex'}}>
                                    <ShoppingCartIcon />
                                    <div className='wishLength'>{addToWishCard.length}</div>
                                </div>
                            </div>
                        </Link>
                    </div>
                </div>
            </div>
            <Outlet />
        </div>
    )
}
