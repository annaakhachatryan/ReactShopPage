import React, { useEffect, useRef, useState } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { selectProductsDataSlice } from '../../store/slices/productSlice/productSlice'
import { addProduct, deleteProduct, editProduct, fetchProducts } from '../../store/slices/productSlice/ProductAPI';
import { Navbar } from '../../components/Navbar/Navbar';
import './Product.css'
import { getEditUser } from '../../store/slices/registrationData/registrationSlice';
import CloudUploadRoundedIcon from '@mui/icons-material/CloudUploadRounded';

export const Products = () => {
    const dispatch = useDispatch();
    const { items } = useSelector(selectProductsDataSlice)
    const [newImg, setNewImg] = useState('');
    const [isFormVisible, setFormVisible] = useState(false);
    const [editProductItem, setEditProductItem] = useState({
        id: '',
        title: '',
        price: '',
        description: '',
        category: '',
        image: '',
    });
    const editProductFormRef = useRef()

    const openForm = () => {
        setFormVisible(true);
    };
    const closeForm = () => {
        setFormVisible(false);
    };

    useEffect(() => {
        dispatch(fetchProducts())
    }, [dispatch])

    const handleDelete = (productId) => {
        dispatch(deleteProduct(productId));
    };

    const onChangeImage = (e) => {
        let reader = new FileReader();
        reader.onload = () => {
            setNewImg(reader.result);
        };
        reader.readAsDataURL(e.target.files[0]);
    };

    const handleSubmit = (event) => {
        event.preventDefault();
        const product = {
            title: event.target.title.value,
            price: event.target.price.value,
            description: event.target.description.value,
            category: event.target.category.value,
            image: newImg,
        };
        dispatch(addProduct(product));
        event.target.reset();
    };

    const handleEdit = (editData) => {
        setEditProductItem({
            id: editData.id,
            title: editData.title,
            price: editData.price,
            description: editData.description,
            category: editData.category,
            image: editData.image
        })
        dispatch(getEditUser(editProductItem));
    };

    const changeInputsValues = (e) => {
        setEditProductItem({
            ...editProductItem,
            [e.target.name]: e.target.value,
        });
    };

    const handleSubmitEdit = (e) => {
        e.preventDefault();
        const [{ value: title }, { value: price }, { value: description }, { value: category }] = editProductFormRef.current;
        dispatch(editProduct({
            id: editProductItem.id,
            title,
            price,
            description,
            category,
            image: newImg ? newImg : editProductItem.image
        }))
        setEditProductItem({
            id: '',
            title: '',
            price: '',
            description: '',
            category: '',
            image: ''
        })
        alert('You have already edited the product!')
    };

    return (
        <div className='Product'>
            <Navbar />
            <h2 style={{ textAlign: 'center' }}>Add Products</h2>
            <form onSubmit={handleSubmit}>
                <input type="text" name="title" placeholder="Product title" required />
                <input type='text' name="price" placeholder="Product price" required />
                <input type='text' name="description" placeholder="Product description" required />
                <input type='text' name="category" placeholder="Product category" required />
                <div className='choose'>
                    <CloudUploadRoundedIcon className='iconFile' /> Upload a file
                    <input type='file' onChange={(e) => onChangeImage(e)} />
                </div>
                <button className='btn' type="submit">Add Product</button>
            </form>

            <table>
                <th>ID</th>
                <th>Title</th>
                <th>Price</th>
                <th>Description</th>
                <th>Category</th>
                <th>Image</th>
                <th>Delete</th>
                <th>Edit</th>
                {items.map((product) => (
                    <tr className='eachProduct' key={product?.id}>
                        <td>{product?.id}</td>
                        <td style={{ width: '150px' }}>{product?.title}</td>
                        <td>$ {product?.price}</td>
                        <td style={{ width: '200px' }}>{product?.description}</td>
                        <td>{product?.category}</td>
                        <td><img style={{ width: '50px', height: '50px' }} src={product.image} alt='' /></td>
                        <td><button className='btn' onClick={() => handleDelete(product.id)}>Delete</button></td>
                        <td><button className='btn' onClick={() => handleEdit(product)}> {!isFormVisible && <span onClick={openForm}>Edit</span>} </button></td>
                    </tr>
                ))}
            </table>

            {
                isFormVisible && (
                    <div className='productContainer'>
                        <div className='productFormAnimation'>
                            <form ref={editProductFormRef} onSubmit={handleSubmitEdit}>
                                <input type="text"
                                    onChange={changeInputsValues}
                                    value={editProductItem?.title ? editProductItem.title : ''}
                                    name="title" placeholder="Product title" required />
                                <input type='text'
                                    onChange={changeInputsValues}
                                    value={editProductItem?.price ? editProductItem.price : ''}
                                    name="price"
                                    placeholder="Product price"
                                    required />
                                <input type='text'
                                    onChange={changeInputsValues}
                                    value={editProductItem?.description ? editProductItem.description : ''}
                                    name="description"
                                    placeholder="Product description" required />
                                <input type='text'
                                    onChange={changeInputsValues}
                                    value={editProductItem?.category ? editProductItem.category : ''}
                                    name="category"
                                    placeholder="Product category" required />
                                <div className='choose'>
                                    <CloudUploadRoundedIcon className='iconFile' /> Upload a file
                                    <input type='file' onChange={(e) => onChangeImage(e)} />
                                </div>

                                <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                                    <button className='btn'>Edit</button>
                                    <button className='btn' onClick={closeForm} >Close</button>
                                </div>
                            </form>
                        </div>
                    </div>
                )
            }
        </div>
    )
}